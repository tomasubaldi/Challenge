class Config:
    NEW_YORK_TIMES_URL ='https://www.nytimes.com/'
    SEARCH_PHRASE = 'lake michigan'
    SECTION = ['Books', 'Opinion']
    MONTHS_BACK = 10