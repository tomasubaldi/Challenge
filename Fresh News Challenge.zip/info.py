class Info:
    def __init__(self):
        self.title: str = ""
        self.date = ""
        self.description = ""
        self.picture_link = ""
        self.picture_filename = ""
        self.phrase_count = ""
        self.contains_money = ""
